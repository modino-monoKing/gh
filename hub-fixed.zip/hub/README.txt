1) Android Studio: New Project > Empty Views Activity (package com.example.hub, minSdk 26).
2) انسخ app/ فوق مجلد app (build.gradle.kts, proguard-rules.pro, src/main) وتأكد من plugin kotlin.android.
3) 3 ألعاب مرفقة (assets/games) تُنسخ تلقائيًا عند أول تشغيل. غيّر رقم seed في GameSeed لإعادة النسخ.
4) إضافة لعبة/مشروع: ZIP فيه index.html و app.json (sample-project).
   app.json (+ "category":"ألعاب" للتصنيف): {"id","name","permissions":[camera,mic,location],"background":false,"orientation":"auto|portrait|landscape","fullscreen":true}
5) حتى 8 مشاريع معًا، كل واحد بعملية مستقلة (:p0..:p7).
6) Release: Build > Generate Signed Bundle/APK > APK > release.
