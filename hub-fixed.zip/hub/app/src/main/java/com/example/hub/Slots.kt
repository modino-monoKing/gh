package com.example.hub
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Process
import android.widget.Toast
import androidx.activity.ComponentActivity
import java.io.File

/** 8 شرائح: كل شريحة = عملية مستقلة (:p0..:p7) يعمل فيها مشروع واحد */
object Slots {
    const val N = 8
    private fun file(c: Context, s: Int) = File(c.filesDir, "slots/p$s")

    fun mySlot() = runCatching { File("/proc/self/cmdline").readText().trim('\u0000').substringAfterLast(":p").toInt() }.getOrDefault(0)

    /** الشرائح الحية: slot -> (projectId, pid) */
    fun live(c: Context): Map<Int, Pair<String, Int>> {
        val procs = (c.getSystemService(ActivityManager::class.java).runningAppProcesses ?: emptyList()).associate { it.processName to it.pid }
        val out = mutableMapOf<Int, Pair<String, Int>>()
        for (s in 0 until N) {
            val f = file(c, s); if (!f.exists()) continue
            val parts = f.readText().split("|")
            if (parts.size == 2 && procs["${c.packageName}:p$s"] == parts[1].toIntOrNull()) out[s] = parts[0] to parts[1].toInt() else f.delete()
        }
        return out
    }
    fun pick(c: Context, id: String): Int? {
        val l = live(c)
        l.entries.firstOrNull { it.value.first == id }?.let { return it.key }
        return (0 until N).firstOrNull { it !in l }
    }
    fun claim(c: Context, s: Int, id: String) { file(c, s).apply { parentFile!!.mkdirs() }.writeText("$id|${Process.myPid()}") }
    fun release(c: Context, s: Int) { file(c, s).delete() }
    fun owner(c: Context, s: Int): Pair<String, Int>? =
        file(c, s).takeIf { it.exists() }?.readText()?.split("|")?.takeIf { it.size == 2 }?.let { it[0] to (it[1].toIntOrNull() ?: -1) }
}

object Launch {
    /** نقطة الدخول الموحدة للقائمة والاختصارات والإشعارات */
    fun intent(c: Context, id: String) = Intent(c, LauncherActivity::class.java).setAction(Intent.ACTION_VIEW)
        .setData(Uri.parse("hub://launch/$id")).putExtra("id", id)
}

class LauncherActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        intent.getStringExtra("id")?.let { id ->
            val slot = Slots.pick(this, id)
            if (slot == null) Toast.makeText(this, "الحد الأقصى ${Slots.N} مشاريع تعمل معًا", Toast.LENGTH_LONG).show()
            else startActivity(Intent(this, ProjectActivity.SLOTS[slot]).setAction(Intent.ACTION_VIEW)
                .setData(Uri.parse("hub://project/$id")).putExtra("id", id).addFlags(Intent.FLAG_ACTIVITY_NEW_DOCUMENT))
        }
        finish()
    }
}
