package com.example.hub
import android.Manifest
import android.content.Context
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Process
import android.view.WindowManager
import android.webkit.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import java.io.File

open class ProjectActivity : ComponentActivity() {
    private lateinit var web: WebView
    private lateinit var project: ProjectManager.Project
    private var slot = 0
    private var pending: (Boolean) -> Unit = {}
    private val req = registerForActivityResult(ActivityResultContracts.RequestPermission()) { pending(it) }

    private val map = mapOf("camera" to Manifest.permission.CAMERA, "mic" to Manifest.permission.RECORD_AUDIO,
        "location" to Manifest.permission.ACCESS_FINE_LOCATION)

    /** طلب كسول: لا يسأل المستخدم إلا عند أول استخدام فعلي، ويرفض ما لم يعلنه المشروع */
    private fun ask(name: String, cb: (Boolean) -> Unit) {
        val perm = map[name]
        if (perm == null || name !in project.perms) { DebugLog.perm(project.id, name, "مرفوض: غير معلن في app.json"); cb(false); return }
        if (ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED) {
            DebugLog.perm(project.id, name, "ممنوح"); cb(true); return
        }
        pending = { ok -> DebugLog.perm(project.id, name, if (ok) "ممنوح" else "رفضه المستخدم"); cb(ok) }
        req.launch(perm)
    }

    private fun grantAll(need: List<Pair<String, String>>, ok: MutableList<String>, r: PermissionRequest) {
        if (need.isEmpty()) { if (ok.isEmpty()) r.deny() else r.grant(ok.toTypedArray()); return }
        val (name, res) = need.first()
        ask(name) { if (it) ok.add(res); grantAll(need.drop(1), ok, r) }
    }

    /** جسر قياس الأداء: JS يعدّ إطارات requestAnimationFrame ويرسل FPS ونسبة التقطيع كل ثانيتين */
    inner class Perf {
        @JavascriptInterface fun r(fps: Int, jank: Int) { DebugLog.stat(project.id, fps, jank) }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        slot = Slots.mySlot()
        val id = intent.getStringExtra("id") ?: return finish()
        val owner = Slots.owner(this, slot)
        if (owner != null && owner.second == Process.myPid() && owner.first != id) {   // الشريحة مشغولة بمشروع آخر
            startActivity(Launch.intent(this, id)); finish(); return
        }
        Slots.claim(this, slot, id)
        project = ProjectManager.load(this, id)

        requestedOrientation = when (project.orientation) {
            "landscape" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            "portrait" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/p/", WebViewAssetLoader.InternalStoragePathHandler(this, ProjectManager.dir(this))).build()
        web = WebView(this).also { setContentView(it) }
        if (project.fullscreen) WindowInsetsControllerCompat(window, web).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
        web.settings.apply { javaScriptEnabled = true; domStorageEnabled = true; allowFileAccess = false; mediaPlaybackRequiresUserGesture = false }
        web.addJavascriptInterface(Perf(), "Perf")
        if (BuildConfigDebug.on(this)) WebView.setWebContentsDebuggingEnabled(true)

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest) = loader.shouldInterceptRequest(r.url)
            override fun onReceivedError(v: WebView, r: WebResourceRequest, e: WebResourceError) {
                DebugLog.add(project.id, "NET", "${e.description} ← ${r.url}")
            }
            override fun onPageFinished(v: WebView, url: String?) { v.evaluateJavascript(PERF_JS, null) }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                DebugLog.add(project.id, m.messageLevel().name, "${m.message()} (${m.sourceId().substringAfterLast('/')}:${m.lineNumber()})"); return true
            }
            override fun onPermissionRequest(r: PermissionRequest) = runOnUiThread {
                val need = r.resources.mapNotNull {
                    when (it) {
                        PermissionRequest.RESOURCE_VIDEO_CAPTURE -> "camera" to it
                        PermissionRequest.RESOURCE_AUDIO_CAPTURE -> "mic" to it
                        else -> null
                    }
                }
                grantAll(need, mutableListOf(), r)
            }
            override fun onGeolocationPermissionsShowPrompt(origin: String, cb: GeolocationPermissions.Callback) {
                ask("location") { cb.invoke(origin, it, false) }
            }
        }
        web.loadUrl("https://appassets.androidplatform.net/p/${project.id}/index.html")
        if (project.background) KeepAliveService.add(this, project.id)
    }

    override fun onPause() { super.onPause(); if (::web.isInitialized) web.onPause() }
    override fun onResume() { super.onResume(); if (::web.isInitialized) web.onResume() }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing && ::project.isInitialized) {
            if (project.background) KeepAliveService.remove(this, project.id)
            Slots.release(this, slot); DebugLog.clearStat(project.id)
            Process.killProcess(Process.myPid())   // تحرير الشريحة والذاكرة فورًا
        }
    }

    companion object {
        val SLOTS: List<Class<out ProjectActivity>> = listOf(P0::class.java, P1::class.java, P2::class.java, P3::class.java,
            P4::class.java, P5::class.java, P6::class.java, P7::class.java)

        private const val PERF_JS = """(function(){if(window.__perf)return;window.__perf=1;var f=0,j=0,l=performance.now(),s=l;
function t(n){f++;if(n-l>25)j++;l=n;if(n-s>=2000){Perf.r(Math.round(f*1000/(n-s)),Math.round(j*100/f));f=0;j=0;s=n}requestAnimationFrame(t)}
requestAnimationFrame(t)})();"""

        fun pinShortcut(c: Context, p: ProjectManager.Project) {
            val bmp: Bitmap? = File(ProjectManager.dir(c), "${p.id}/icon.png").takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }
            val icon = bmp?.let { IconCompat.createWithBitmap(it) } ?: IconCompat.createWithResource(c, android.R.drawable.sym_def_app_icon)
            val info = ShortcutInfoCompat.Builder(c, p.id).setShortLabel(p.name).setIcon(icon).setIntent(Launch.intent(c, p.id)).build()
            ShortcutManagerCompat.requestPinShortcut(c, info, null)
        }
    }
}

class P0 : ProjectActivity(); class P1 : ProjectActivity(); class P2 : ProjectActivity(); class P3 : ProjectActivity()
class P4 : ProjectActivity(); class P5 : ProjectActivity(); class P6 : ProjectActivity(); class P7 : ProjectActivity()

object BuildConfigDebug {
    fun on(c: Context) = (c.applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0
}
