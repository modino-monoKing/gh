package com.example.hub
import android.app.Application
import java.io.File

/** يعمل في كل عملية (الحاوية + كل شريحة مشروع) */
class HubApp : Application() {
    override fun onCreate() {
        super.onCreate()
        DebugLog.init(this)
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            val proc = runCatching { File("/proc/self/cmdline").readText().trim('\u0000') }.getOrDefault("?")
            runCatching { File(filesDir, "crash.txt").appendText("${System.currentTimeMillis()} [$proc]\n${e.stackTraceToString()}\n") }
            DebugLog.add(proc.substringAfterLast(':'), "CRASH", e.toString())
            old?.uncaughtException(t, e)
        }
    }
}
