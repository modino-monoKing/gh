package com.example.hub
import android.content.Context
import android.net.Uri
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipInputStream

object ProjectManager {
    data class Project(val id: String, val name: String, val perms: Set<String>, val background: Boolean,
                       val orientation: String, val fullscreen: Boolean, val category: String = "عام")

    fun dir(c: Context) = File(c.filesDir, "projects").apply { mkdirs() }

    /** app.json: {"id","name","permissions":["camera","mic","location"],"background":false,"orientation":"auto|portrait|landscape","fullscreen":true} */
    fun install(c: Context, uri: Uri): Result<String> = runCatching {
        val tmp = File(c.cacheDir, "in_${System.nanoTime()}").apply { mkdirs() }
        try {
            c.contentResolver.openInputStream(uri)!!.use { ins ->
                ZipInputStream(ins).use { z ->
                    var e = z.nextEntry
                    while (e != null) {
                        val out = File(tmp, e.name)
                        require(out.canonicalPath.startsWith(tmp.canonicalPath + File.separator)) { "مسار ZIP غير آمن" }
                        if (e.isDirectory) out.mkdirs() else { out.parentFile!!.mkdirs(); out.outputStream().use { z.copyTo(it) } }
                        e = z.nextEntry
                    }
                }
            }
            var root = tmp
            if (!File(root, "index.html").exists()) root = tmp.listFiles()?.singleOrNull { it.isDirectory } ?: tmp
            require(File(root, "index.html").exists()) { "index.html غير موجود" }
            val meta = File(root, "app.json").takeIf { it.exists() }?.let { JSONObject(it.readText()) } ?: JSONObject()
            val id = meta.optString("id", "p${System.currentTimeMillis()}").replace(Regex("[^A-Za-z0-9_-]"), "_")
            val dest = File(dir(c), id).apply { deleteRecursively() }
            root.copyRecursively(dest)
            id
        } finally { tmp.deleteRecursively() }
    }

    fun load(c: Context, id: String): Project {
        val m = File(dir(c), "$id/app.json").takeIf { it.exists() }?.let { JSONObject(it.readText()) } ?: JSONObject()
        val arr = m.optJSONArray("permissions")
        val perms = (0 until (arr?.length() ?: 0)).map { arr!!.getString(it) }.toSet()
        return Project(id, m.optString("name", id), perms, m.optBoolean("background", false),
            m.optString("orientation", "auto"), m.optBoolean("fullscreen", false), m.optString("category", "عام"))
    }

    fun list(c: Context) = (dir(c).listFiles() ?: emptyArray()).filter { it.isDirectory }.map { load(c, it.name) }.sortedBy { it.name }
    /** يحفظ التصنيف داخل app.json الخاص بالمشروع */
    fun setCategory(c: Context, id: String, cat: String) {
        val f = File(dir(c), "$id/app.json")
        val m = if (f.exists()) JSONObject(f.readText()) else JSONObject().put("id", id)
        f.writeText(m.put("category", cat.trim().ifEmpty { "عام" }).toString())
    }
    fun delete(c: Context, id: String) { File(dir(c), id).deleteRecursively(); DebugLog.clearStat(id) }
}

/** ينسخ الألعاب المرفقة (assets/games) إلى المكتبة مرة واحدة */
object GameSeed {
    fun run(c: Context) {
        val sp = c.getSharedPreferences("hub", 0)
        if (sp.getInt("seed", 0) >= 1) return
        c.assets.list("games")?.forEach { g -> copy(c, "games/$g", File(ProjectManager.dir(c), g)) }
        sp.edit().putInt("seed", 1).apply()
    }
    private fun copy(c: Context, path: String, dest: File) {
        val kids = c.assets.list(path)
        if (kids.isNullOrEmpty()) { dest.parentFile!!.mkdirs(); c.assets.open(path).use { i -> dest.outputStream().use { i.copyTo(it) } } }
        else { dest.mkdirs(); kids.forEach { copy(c, "$path/$it", File(dest, it)) } }
    }
}
