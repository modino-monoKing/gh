package com.example.hub
import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/** كل مشروع في عملية مستقلة، لذا السجل والأذونات والإحصاءات تُخزَّن في ملفات تقرؤها الحاوية */
object DebugLog {
    private lateinit var root: File
    private fun dir(n: String) = File(root, n).apply { mkdirs() }
    private fun now() = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
    fun init(c: Context) { root = File(c.filesDir, "dbg").apply { mkdirs() } }

    @Synchronized fun add(project: String, level: String, msg: String) {
        runCatching {
            val f = File(dir("logs"), "$project.log")
            if (f.length() > 200_000) f.writeText(f.readText().takeLast(60_000))
            f.appendText("${now()} [$project] $level: ${msg.take(400)}\n")
        }
    }

    fun perm(project: String, perm: String, state: String) {
        runCatching {
            val f = File(dir("perms"), "$project.properties"); val p = Properties()
            if (f.exists()) f.inputStream().use { p.load(it) }
            p.setProperty(perm, "$state (${now()})")
            f.outputStream().use { p.store(it, null) }
        }
    }

    fun perms(project: String): Map<String, String> = runCatching {
        val f = File(dir("perms"), "$project.properties")
        if (!f.exists()) emptyMap() else {
            val p = Properties(); f.inputStream().use { p.load(it) }
            p.entries.associate { it.key.toString() to it.value.toString() }
        }
    }.getOrDefault(emptyMap())

    fun stat(project: String, fps: Int, jank: Int) {
        runCatching { File(dir("stats"), "$project.txt").writeText("$fps|$jank|${System.currentTimeMillis()}") }
    }
    fun clearStat(project: String) { File(dir("stats"), "$project.txt").delete() }
    /** (fps, jank%, عمر القراءة بالمللي ثانية) */
    fun readStat(project: String): Triple<Int, Int, Long>? = runCatching {
        val s = File(dir("stats"), "$project.txt").readText().split("|")
        Triple(s[0].toInt(), s[1].toInt(), System.currentTimeMillis() - s[2].toLong())
    }.getOrNull()

    fun dump(): String = (dir("logs").listFiles() ?: emptyArray()).flatMap { it.readLines().takeLast(80) }.sorted().joinToString("\n")
}
