package com.example.hub
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

class KeepAliveService : Service() {
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, sid: Int): Int {
        i?.getStringExtra("add")?.let { running[it] = ProjectManager.load(this, it) }
        i?.getStringExtra("remove")?.let { running.remove(it) }
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("keep", "مشاريع تعمل", NotificationManager.IMPORTANCE_LOW))
        val b = NotificationCompat.Builder(this, "keep").setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true)
            .setContentTitle("مشاريع تعمل في الخلفية").setContentText(running.values.joinToString("، ") { it.name })
        running.values.take(3).forEach { p ->
            b.addAction(0, p.name, PendingIntent.getActivity(this, p.id.hashCode(), Launch.intent(this, p.id),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        }
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, 1, b.build(), type)
        if (running.isEmpty()) { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
        return START_NOT_STICKY
    }

    companion object {
        private val running = linkedMapOf<String, ProjectManager.Project>()   // في عملية الحاوية فقط
        fun names() = running.values.map { it.name }
        fun add(c: Context, id: String) = ContextCompat.startForegroundService(c, Intent(c, KeepAliveService::class.java).putExtra("add", id))
        fun remove(c: Context, id: String) = ContextCompat.startForegroundService(c, Intent(c, KeepAliveService::class.java).putExtra("remove", id))
    }
}
