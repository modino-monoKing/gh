package com.example.hub
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.activity.ComponentActivity
import java.io.File

/** سجل مباشر + فحص ذاتي + آخر انهيار + مشاركة التقرير */
class DebugActivity : ComponentActivity() {
    private lateinit var tv: TextView

    private fun selfCheck(): String = ProjectManager.list(this).joinToString("\n") { p ->
        val d = File(ProjectManager.dir(this), p.id)
        val issues = buildList {
            if (!File(d, "index.html").exists()) add("index.html مفقود")
            if (!File(d, "app.json").exists()) add("app.json مفقود")
            (p.perms - setOf("camera", "mic", "location")).forEach { add("إذن غير مدعوم: $it") }
            if (d.walkTopDown().sumOf { it.length() } > 200L shl 20) add("الحجم > 200MB")
        }
        "${p.name}: ${if (issues.isEmpty()) "سليم" else issues.joinToString("، ")}"
    }.ifEmpty { "لا مشاريع" }

    private fun report(): String {
        val crash = File(filesDir, "crash.txt").takeIf { it.exists() }?.readText()?.takeLast(1500) ?: "لا انهيارات"
        return "— فحص —\n${selfCheck()}\n\n— آخر انهيار —\n$crash\n\n— السجل —\n${DebugLog.dump()}"
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        tv = TextView(this).apply { textSize = 12f; setTextIsSelectable(true) }
        val bar = LinearLayout(this)
        fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a() }; bar.addView(this, LinearLayout.LayoutParams(0, -2, 1f)) }
        btn("تحديث") { tv.text = report() }
        btn("مسح") { File(filesDir, "crash.txt").delete(); tv.text = report() }
        btn("مشاركة") {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, report()), null))
        }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24); fitsSystemWindows = true }
        root.addView(bar); root.addView(ScrollView(this).apply { addView(tv) })
        setContentView(root)
        tv.text = report()
    }
}
