package com.example.hub
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.widget.doAfterTextChanged

/** المكتبة: بحث + تصنيفات + إضافة + تشغيل + اختصار + حذف */
class MainActivity : ComponentActivity() {
    private lateinit var list: ListView
    private lateinit var search: EditText
    private lateinit var spinner: Spinner
    private var all = listOf<ProjectManager.Project>()
    private var shown = listOf<ProjectManager.Project>()
    private var cats = listOf<String>()
    private var live = setOf<String>()

    private val pick = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            ProjectManager.install(this, uri)
                .onFailure { DebugLog.add("install", "ERROR", it.toString()); Toast.makeText(this, it.message, Toast.LENGTH_LONG).show() }
            loadAll()
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        GameSeed.run(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24); fitsSystemWindows = true }
        val row = LinearLayout(this)
        fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a() }; row.addView(this, LinearLayout.LayoutParams(0, -2, 1f)) }
        btn("+ إضافة") { pick.launch(arrayOf("application/zip", "application/x-zip-compressed")) }
        btn("المراقبة") { startActivity(Intent(this, MonitorActivity::class.java)) }
        btn("Debug") { startActivity(Intent(this, DebugActivity::class.java)) }

        search = EditText(this).apply { hint = "بحث بالاسم أو التصنيف"; setSingleLine(); doAfterTextChanged { applyFilter() } }
        spinner = Spinner(this).apply {
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = applyFilter()
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }
        list = ListView(this)
        root.addView(row); root.addView(search); root.addView(spinner); root.addView(list)
        setContentView(root)

        list.setOnItemClickListener { _, _, i, _ -> startActivity(Launch.intent(this, shown[i].id)) }
        list.setOnItemLongClickListener { _, _, i, _ ->
            val p = shown[i]
            AlertDialog.Builder(this).setTitle(p.name).setItems(arrayOf("اختصار على الشاشة", "تغيير التصنيف", "حذف")) { _, w ->
                when (w) {
                    0 -> ProjectActivity.pinShortcut(this, p)
                    1 -> askCategory(p)
                    else -> { ProjectManager.delete(this, p.id); loadAll() }
                }
            }.show(); true
        }
    }

    override fun onResume() { super.onResume(); loadAll() }

    private fun askCategory(p: ProjectManager.Project) {
        val input = EditText(this).apply { setText(p.category); setSingleLine() }
        AlertDialog.Builder(this).setTitle("التصنيف").setView(input)
            .setPositiveButton("حفظ") { _, _ -> ProjectManager.setCategory(this, p.id, input.text.toString()); loadAll() }
            .setNegativeButton("إلغاء", null).show()
    }

    /** يقرأ المشاريع ويعيد بناء قائمة التصنيفات مع الاحتفاظ بالاختيار الحالي */
    private fun loadAll() {
        all = ProjectManager.list(this)
        live = Slots.live(this).values.map { it.first }.toSet()
        val prev = spinner.selectedItem as? String
        cats = listOf("الكل") + all.map { it.category }.distinct().sorted()
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, cats.mapIndexed { i, c ->
            if (i == 0) "الكل (${all.size})" else "$c (${all.count { it.category == c }})" })
        spinner.setSelection(cats.indexOf(prev?.substringBefore(" (")).coerceAtLeast(0))
        applyFilter()
    }

    private fun applyFilter() {
        val cat = cats.getOrNull(spinner.selectedItemPosition)?.takeIf { it != "الكل" }
        val q = search.text.toString().trim().lowercase()
        shown = all.filter { (cat == null || it.category == cat) && (q.isEmpty() || it.name.lowercase().contains(q) || it.category.lowercase().contains(q)) }
            .sortedWith(compareByDescending<ProjectManager.Project> { it.id in live }.thenBy { it.name.lowercase() })
        list.adapter = object : ArrayAdapter<ProjectManager.Project>(this, android.R.layout.simple_list_item_2, shown) {
            override fun getView(p: Int, v: View?, g: ViewGroup): View {
                val view = v ?: layoutInflater.inflate(android.R.layout.simple_list_item_2, g, false)
                val it = shown[p]
                view.findViewById<TextView>(android.R.id.text1).text = (if (it.id in live) "● " else "") + it.name
                view.findViewById<TextView>(android.R.id.text2).text =
                    "${it.category} • أذونات: ${it.perms.ifEmpty { setOf("لا شيء") }.joinToString()}" + if (it.background) " • خلفية" else ""
                return view
            }
        }
    }
}
