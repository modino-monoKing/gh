package com.example.hub
import android.app.ActivityManager
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity
import java.io.File

/** لكل مشروع: CPU وRAM وFPS والتقطيع وتقييم الأداء وجدول أذوناته (يُقرأ من /proc/<pid> لأن الشرائح بنفس UID) */
class MonitorActivity : ComponentActivity() {
    private lateinit var tv: TextView
    private val h = Handler(Looper.getMainLooper())
    private val last = HashMap<Int, Pair<Long, Long>>()   // pid -> (ticks, elapsedMs)

    private fun cpu(pid: Int): Double {
        val t = runCatching {
            val f = File("/proc/$pid/stat").readText().substringAfterLast(')').trim().split(" ")
            f[11].toLong() + f[12].toLong()                 // utime + stime بوحدة 10ms
        }.getOrNull() ?: return 0.0
        val now = SystemClock.elapsedRealtime()
        val p = last.put(pid, t to now) ?: return 0.0
        return (t - p.first) * 10.0 / (now - p.second).coerceAtLeast(1) * 100   // 100% = نواة كاملة
    }
    private fun mem(pid: Int) = runCatching {
        getSystemService(ActivityManager::class.java).getProcessMemoryInfo(intArrayOf(pid))[0].totalPss / 1024
    }.getOrDefault(0)

    private fun grade(cpu: Double, fps: Int, jank: Int) = when {
        fps >= 55 && jank <= 5 && cpu < 70 -> "ممتاز"
        fps >= 40 && jank <= 15 && cpu < 90 -> "جيد"
        else -> "ضعيف"
    }

    private val tick = object : Runnable {
        override fun run() {
            val b = batteryIntent()
            val lvl = b.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val temp = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0
            val chg = b.getIntExtra(BatteryManager.EXTRA_STATUS, 0) == BatteryManager.BATTERY_STATUS_CHARGING
            val me = Process.myPid()
            val byId = Slots.live(this@MonitorActivity).values.associate { it.first to it.second }
            val sb = StringBuilder()
            sb.append("الحاوية: CPU %.1f%% • RAM %dMB\n".format(cpu(me), mem(me)))
            sb.append("البطارية: $lvl%${if (chg) " (تشحن)" else ""} • ${temp}°C\n")
            sb.append("خدمة الخلفية: ${KeepAliveService.names().ifEmpty { listOf("لا شيء") }.joinToString()}\n")
            ProjectManager.list(this@MonitorActivity).sortedByDescending { it.id in byId }.forEach { p ->
                sb.append("\n")
                val pid = byId[p.id]
                if (pid == null) sb.append("○ ${p.name}: متوقف\n") else {
                    val c = cpu(pid); val st = DebugLog.readStat(p.id)?.takeIf { it.third < 6000 }
                    sb.append("● ${p.name} (pid $pid)\n  CPU %.1f%% • RAM %dMB".format(c, mem(pid)))
                    if (st != null) sb.append(" • FPS ${st.first} • تقطيع ${st.second}% → ${grade(c, st.first, st.second)}")
                    sb.append("\n")
                }
                val perms = DebugLog.perms(p.id)
                sb.append(if (perms.isEmpty()) "  أذونات: لم تُطلب\n" else perms.entries.joinToString("") { "  ${it.key}: ${it.value}\n" })
            }
            tv.text = sb.toString()
            h.postDelayed(this, 1500)
        }
    }

    private fun batteryIntent(): Intent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))!!

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        tv = TextView(this).apply { setPadding(32, 48, 32, 32); textSize = 14f }
        setContentView(ScrollView(this).apply { addView(tv); fitsSystemWindows = true })
    }
    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
}
